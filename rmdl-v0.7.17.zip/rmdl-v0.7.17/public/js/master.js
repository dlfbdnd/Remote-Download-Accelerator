// <Showing and hiding elements onClick>
document.addEventListener('DOMContentLoaded', function() {
	var elems = document.querySelectorAll('.dropdown-trigger');
	var instances = M.Dropdown.init(elems, function() {
		this.open();
	});
});

document.addEventListener('DOMContentLoaded', function() {
	var elems = document.querySelectorAll('.collapsible');
	var instances = M.Collapsible.init(elems, function() {
		this.open();
	});
});

window.onload = function() {
  document.getElementById("customFileNameC2").onclick = function customFileName() {
  	document.getElementById("customFileName").style.display = "";
  }
  document.getElementById("customFileNameC1").onclick = function customFileName() {
  	document.getElementById("customFileName").style.display = "none";
  }

  document.getElementById("downloadSubtitleC1").onclick = function customFileName() {
  	if (document.getElementById("downloadSubtitle").style.display == "") {
  		document.getElementById("downloadSubtitle").style.display = "none";}
  	else {
  		document.getElementById("downloadSubtitle").style.display = "";
  	}
  }

  document.getElementById("downWithLogin").onclick = function customFileName() {
    if (document.getElementById("downWithLogin1").style.display == "") {
      document.getElementById("downWithLogin1").style.display = "none";}
    else {
      document.getElementById("downWithLogin1").style.display = "";
    }
  }
}
// <Showing and hiding elements onClick/>


// <Alpha Icon>
setAlphaIcon = function(content, printedContent, stepDelay) {
  if (content == "") {
    $("#alphaIcon").animate({
      "vertical-align": "sub",
      "font-size": "50%"
    }, 500)
    return 0;
  };
  setTimeout(function() {
    document.querySelector("a.brand-logo").innerHTML = "RDA <span id=\"alphaIcon\" style=\"font-weight: 400; font-size: 90%;\">" + printedContent + content.substring(0, 1) + "</span>";
    setAlphaIcon(content.substring(1), printedContent += content.substring(0, 1), stepDelay)
  }, stepDelay); 
}

setTimeout(function() {
  setAlphaIcon("v0.7.17", "", 50);
}, 300);
// <Alpha Icon/>


// <dotdotdot>
var dotInterval;
dotdotdot = function() {
  dotInterval = setInterval(function() {
    if (document.querySelectorAll("#dotdotdot")[0].innerHTML == "") {
      document.querySelectorAll("#dotdotdot")[0].innerHTML = "&nbsp;&nbsp;&nbsp;";
    } else if (document.querySelectorAll("#dotdotdot")[0].innerHTML == "&nbsp;&nbsp;&nbsp;") {
      document.querySelectorAll("#dotdotdot")[0].innerHTML = ".&nbsp;&nbsp;";
    } else if (document.querySelectorAll("#dotdotdot")[0].innerHTML == ".&nbsp;&nbsp;") {
      document.querySelectorAll("#dotdotdot")[0].innerHTML = "..&nbsp;";
    } else if (document.querySelectorAll("#dotdotdot")[0].innerHTML == "..&nbsp;") {
      document.querySelectorAll("#dotdotdot")[0].innerHTML = "...";
    } else if (document.querySelectorAll("#dotdotdot")[0].innerHTML == "...") {
    document.querySelectorAll("#dotdotdot")[0].innerHTML = "&nbsp;&nbsp;&nbsp;";
    } else {
      document.querySelectorAll("#dotdotdot")[0].innerHTML == "";
    }
  }, 250);
}
// <dotdotdot/>


// <convertToBytes>
function convertToBytes(text) { 
    var powers = {'k': 1, 'm': 2, 'g': 3, 't': 4, 'p': 5, 'e': 6, 'z': 7, 'y': 8};
    var regex = /(\d+(?:\.\d+)?)\s?(k|m|g|t|p|e|z|y)?b?/i;
    var res = regex.exec(text);
    return res[1] * Math.pow(1000, powers[res[2].toLowerCase()]); // 1 KB = 1000 B here, or 1024
}
// <convertToBytes/>
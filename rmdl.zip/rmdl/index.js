var app = require("express")();
var childProcess = require("child_process");
var bodyParser = require("body-parser");
var express = require('express'), app = express();
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

String.prototype.replaceAll = function (search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};

// Main Page
app.get("/", function (req, res) {
    res.render("index.ejs");
});

// Remote Download Button Clicked
app.post("/download", function (req, res) {
    var downloadLink = req.body.downloadLink;
    if (downloadLink.includes("http") == false)
        res.render("nginx404.ejs");
    else if (downloadLink.includes("www.youtube.com/") == true) {
        var splitDownloadLink = downloadLink.split("watch?v=");
        var filename = splitDownloadLink[splitDownloadLink.length - 1];
        var command = "you-get \'" + downloadLink + "\' -o /var/www/html/rmdl/dl/";
        childProcess.execSync(command);
        var fileTitle = childProcess.execSync("you-get \'" + downloadLink + "\' --json");
        var fileTitleJsonObj = JSON.parse(fileTitle);
        fileTitle = fileTitleJsonObj.title;
        fileTitle = fileTitle.replaceAll("\'", "\\\'").replaceAll("\ ", "\\\ ").replaceAll("\-", "\\\-").replaceAll("\[", "\\\\\[").replaceAll("\]", "\\\\\]").replaceAll("\(", "\\\(").replaceAll("\)", "\\\)").replaceAll("\&", "\\\&").replaceAll("\.", "\\\.").replaceAll("\:", "\\\:");
        fileTitle = fileTitle.substring(0, 60);
        if (fileTitle[fileTitle.length - 1] == "\\") {
            fileTitle = fileTitle.substring(0, 59);
        }
        var filename = childProcess.execSync("ls * | grep -v \".srt\" | grep " + fileTitle, {encoding: 'utf8'});
        var fileLink = "/download/" + encodeURIComponent(filename.trim());  //the .trim will remove leading and trailing whitespace from the string. encodeURIComponent will URL-encode it.
        res.render("downloadReturn.ejs", {filename: filename, fileLink: fileLink});
    } else if (downloadLink.includes("www.xiami.com/") == true) {
        var splitDownloadLink = downloadLink.split("watch?v=");
        var filename = splitDownloadLink[splitDownloadLink.length - 1];
        var command = "you-get \'" + downloadLink + "\' -o /var/www/html/rmdl/dl/";
        childProcess.execSync(command);
        var fileTitle = childProcess.execSync("you-get \'" + downloadLink + "\' --json");
        var fileTitleJsonObj = JSON.parse(fileTitle);
        fileTitle = fileTitleJsonObj.title;
        fileTitle = fileTitle.replaceAll("\'", "\\\'").replaceAll("\ ", "\\\ ").replaceAll("\-", "\\\-").replaceAll("\[", "\\\\\[").replaceAll("\]", "\\\\\]").replaceAll("\(", "\\\(").replaceAll("\)", "\\\)").replaceAll("\&", "\\\&").replaceAll("\.", "\\\.").replaceAll("\:", "\\\:");
        fileTitle = fileTitle.substring(0, 60);
        if (fileTitle[fileTitle.length - 1] == "\\") {
            fileTitle = fileTitle.substring(0, 59);
        }
        var filename = childProcess.execSync("ls * | grep -v \".lrc\" | grep " + fileTitle, {encoding: 'utf8'});
        var fileLink = "/download/" + encodeURIComponent(filename.trim());  //the .trim will remove leading and trailing whitespace from the string. encodeURIComponent will URL-encode it.
        res.render("downloadReturn.ejs", {filename: filename, fileLink: fileLink});
    } else if (downloadLink.includes("www.youtube.com") || downloadLink.includes("twitter.com") || downloadLink.includes("vk.com") || downloadLink.includes("vine.co") || downloadLink.includes("vimeo.com") || downloadLink.includes("vidto.me") || downloadLink.includes("videomega.tv") || downloadLink.includes("www.veoh.com") || downloadLink.includes("www.tumblr.com") || downloadLink.includes("www.ted.com") || downloadLink.includes("soundcloud.com") || downloadLink.includes("www.showroom-live.com") || downloadLink.includes("www.pinterest.com") || downloadLink.includes("en.musicplayon.com") || downloadLink.includes("www.mtv81.com") || downloadLink.includes("www.mixcloud.com") || downloadLink.includes("www.metacafe.com") || downloadLink.includes("www.magisto.com") || downloadLink.includes("www.khanacademy.org") || downloadLink.includes("archive.org") || downloadLink.includes("instagram.com") || downloadLink.includes("www.infoq.compresentations") || downloadLink.includes("imgur.com") || downloadLink.includes("www.heavy-music.ru") || downloadLink.includes("plus.google.com") || downloadLink.includes("www.freesound.org") || downloadLink.includes("www.flickr.com") || downloadLink.includes("video.fc2.com") || downloadLink.includes("www.facebook.com") || downloadLink.includes("www.ehow.com") || downloadLink.includes("www.dailymotion.com") || downloadLink.includes("www.cbs.com") || downloadLink.includes("bandcamp.com") || downloadLink.includes("alive.in.th") || downloadLink.includes("ch.interest.metvn") || downloadLink.includes("7gogo.jp") || downloadLink.includes("www.nicovideo.jp") || downloadLink.includes("v.163.com") || downloadLink.includes("music.163.com") || downloadLink.includes("www.56.com") || downloadLink.includes("www.acfun.tv") || downloadLink.includes("tieba.baidu.com") || downloadLink.includes("www.baomihua.com") || downloadLink.includes("www.bilibili.com") || downloadLink.includes("www.dilidili.com") || downloadLink.includes("www.douban.com") || downloadLink.includes("www.douyutv.com") || downloadLink.includes("www.panda.tv") || downloadLink.includes("v.ifeng.com") || downloadLink.includes("www.fun.tv") || downloadLink.includes("www.iqiyi.com") || downloadLink.includes("www.joy.cn") || downloadLink.includes("www.ku6.com") || downloadLink.includes("www.kugou.com") || downloadLink.includes("www.kuwo.cn") || downloadLink.includes("www.le.com") || downloadLink.includes("www.lizhi.fm") || downloadLink.includes("www.miaopai.com") || downloadLink.includes("www.miomio.tv") || downloadLink.includes("www.pixnet.net") || downloadLink.includes("www.pptv.com") || downloadLink.includes("v.iqilu.com") || downloadLink.includes("v.qq.com") || downloadLink.includes("live.qq.com") || downloadLink.includes("video.sina.com.cn") || downloadLink.includes("video.weibo.com") || downloadLink.includes("tv.sohu.com") || downloadLink.includes("www.tudou.com") || downloadLink.includes("www.xiami.com") || downloadLink.includes("www.isuntv.com") || downloadLink.includes("www.yinyuetai.com") || downloadLink.includes("www.youku.com") || downloadLink.includes("www.zhanqi.tvlives") || downloadLink.includes("www.cntv.cn") || downloadLink.includes("huaban.com") || downloadLink.includes("tvcast.naver.com") || downloadLink.includes("www.mgtv.com") || downloadLink.includes("www.huomao.com") || downloadLink.includes("www.quanmin.tv")) {
        res.send("This website is not yet supported, notify us so we can add support!");
    } else {
        var splitDownloadLink = downloadLink.split("/");
        var filename = splitDownloadLink[splitDownloadLink.length - 1];
        var command = "wget \'" + downloadLink + "\' -O /var/www/html/rmdl/dl/" + filename;
        childProcess.execSync(command);
        var fileLink = "/download/" + filename;
        res.render("downloadReturn.ejs", {filename: filename, downloadLink: downloadLink, fileLink: fileLink});
    }
});

// Confirm Linked Page
app.get("/download/:filenamed", function (req, res) {
    res.sendFile("/var/www/html/rmdl/dl/" + req.params.filenamed);
});

// 404 for nginx
app.get("*", function (req, res) {
    res.render("nginx404.ejs");
})

app.listen(80);

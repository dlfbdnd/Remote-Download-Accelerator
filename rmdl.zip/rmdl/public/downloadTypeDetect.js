var downloadLink = document.querySelector("#downloadLink");
var downloadType = document.querySelector("#downloadType");
var downloadTypeVar = document.querySelector("#downloadTypeVar");


downloadLink.addEventListener("keyup", function(){
	var content = downloadLink.value;
	content = content.toLowerCase();
	if (content.includes("youtube")) {
		downloadType.classList.remove("hidden");
		downloadTypeVar.textContent = "YouTube Video";
	}
	else if (content.includes("www.xiami.com")) {
		downloadType.classList.remove("hidden");
		downloadTypeVar.textContent = "Xiami Music";
	}
	else if (content.includes("www.youtube.com") || content.includes("twitter.com") || content.includes("vk.com") || content.includes("vine.co") || content.includes("vimeo.com") || content.includes("vidto.me") || content.includes("videomega.tv") || content.includes("www.veoh.com") || content.includes("www.tumblr.com") || content.includes("www.ted.com") || content.includes("soundcloud.com") || content.includes("www.showroom-live.com") || content.includes("www.pinterest.com") || content.includes("en.musicplayon.com") || content.includes("www.mtv81.com") || content.includes("www.mixcloud.com") || content.includes("www.metacafe.com") || content.includes("www.magisto.com") || content.includes("www.khanacademy.org") || content.includes("archive.org") || content.includes("instagram.com") || content.includes("www.infoq.compresentations") || content.includes("imgur.com") || content.includes("www.heavy-music.ru") || content.includes("plus.google.com") || content.includes("www.freesound.org") || content.includes("www.flickr.com") || content.includes("video.fc2.com") || content.includes("www.facebook.com") || content.includes("www.ehow.com") || content.includes("www.dailymotion.com") || content.includes("www.cbs.com") || content.includes("bandcamp.com") || content.includes("alive.in.th") || content.includes("ch.interest.metvn") || content.includes("7gogo.jp") || content.includes("www.nicovideo.jp") || content.includes("v.163.com") || content.includes("music.163.com") || content.includes("www.56.com") || content.includes("www.acfun.tv") || content.includes("tieba.baidu.com") || content.includes("www.baomihua.com") || content.includes("www.bilibili.com") || content.includes("www.dilidili.com") || content.includes("www.douban.com") || content.includes("www.douyutv.com") || content.includes("www.panda.tv") || content.includes("v.ifeng.com") || content.includes("www.fun.tv") || content.includes("www.iqiyi.com") || content.includes("www.joy.cn") || content.includes("www.ku6.com") || content.includes("www.kugou.com") || content.includes("www.kuwo.cn") || content.includes("www.le.com") || content.includes("www.lizhi.fm") || content.includes("www.miaopai.com") || content.includes("www.miomio.tv") || content.includes("www.pixnet.net") || content.includes("www.pptv.com") || content.includes("v.iqilu.com") || content.includes("v.qq.com") || content.includes("live.qq.com") || content.includes("video.sina.com.cn") || content.includes("video.weibo.com") || content.includes("tv.sohu.com") || content.includes("www.tudou.com") || content.includes("www.xiami.com") || content.includes("www.isuntv.com") || content.includes("www.yinyuetai.com") || content.includes("www.youku.com") || content.includes("www.zhanqi.tvlives") || content.includes("www.cntv.cn") || content.includes("huaban.com") || content.includes("tvcast.naver.com") || content.includes("www.mgtv.com") || content.includes("www.huomao.com") || content.includes("www.quanmin.tv")) {
		downloadType.classList.remove("hidden");
		downloadTypeVar.textContent = "Streaming Media (Under Test)";
	}
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	// else if () {
	// 	downloadType.classList.remove("hidden");
	// 	downloadTypeVar.textContent = "";
	// }
	else {
		var content = "." + content.split(".")[content.split(".").length-1]; //This time, file extension detection only
		if (content.includes(".0") || content.includes(".1st") || content.includes(".600") || content.includes(".602") || content.includes(".abw") || content.includes(".acl") || content.includes(".afp") || content.includes(".ami") || content.includes(".amigaguide") || content.includes(".ans") || content.includes(".asc") || content.includes(".aww") || content.includes(".ccf") || content.includes(".csv") || content.includes(".cwk") || content.includes(".dbk") || content.includes(".doc") || content.includes(".docm") || content.includes(".docx") || content.includes(".dot") || content.includes(".dotx") || content.includes(".egt") || content.includes(".epub") || content.includes(".ezw") || content.includes(".fdx") || content.includes(".ftm") || content.includes(".ftx") || content.includes(".gdoc") || content.includes(".html") || content.includes(".hwp") || content.includes(".hwpml") || content.includes(".log") || content.includes(".lwp") || content.includes(".mbp") || content.includes(".md") || content.includes(".me") || content.includes(".mcw") || content.includes(".mobi") || content.includes(".nb") || content.includes(".nbp") || content.includes(".neis") || content.includes(".odm") || content.includes(".odt") || content.includes(".ott") || content.includes(".omm") || content.includes(".pages") || content.includes(".pap") || content.includes(".pdax") || content.includes(".pdf") || content.includes(".quox") || content.includes(".radix-64") || content.includes(".rtf") || content.includes(".rpt") || content.includes(".sdw") || content.includes(".se") || content.includes(".stw") || content.includes(".sxw") || content.includes(".tex") || content.includes(".info") || content.includes(".troff") || content.includes(".txt") || content.includes(".uof") || content.includes(".uoml") || content.includes(".via") || content.includes(".wpd") || content.includes(".wps") || content.includes(".wpt") || content.includes(".wrd") || content.includes(".wrf") || content.includes(".wri") || content.includes(".xhtml") || content.includes(".xht ") || content.includes(".xml") || content.includes(".xps")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Document";
		}
		else if (content.includes(".4db") || content.includes(".4dd") || content.includes(".4dindy") || content.includes(".4dindx") || content.includes(".4dr") || content.includes(".accdb") || content.includes(".accde") || content.includes(".adt") || content.includes(".apr") || content.includes(".box") || content.includes(".chml") || content.includes(".daf") || content.includes(".dat") || content.includes(".dat") || content.includes(".db") || content.includes(".db") || content.includes(".dbf") || content.includes(".egt") || content.includes(".ess") || content.includes(".eap") || content.includes(".fdb") || content.includes(".fdb") || content.includes(".fp") || content.includes(".fp3") || content.includes(".fp5") || content.includes(".fp7") || content.includes(".frm") || content.includes(".gdb") || content.includes(".gtable") || content.includes(".kexi") || content.includes(".kexic") || content.includes(".kexis") || content.includes(".ldb") || content.includes(".mda") || content.includes(".mdb") || content.includes(".adp") || content.includes(".mde") || content.includes(".mdf") || content.includes(".myd") || content.includes(".myi") || content.includes(".ncf") || content.includes(".nsf") || content.includes(".ntf") || content.includes(".nv2") || content.includes(".odb") || content.includes(".ora") || content.includes(".pcontact") || content.includes(".pdb") || content.includes(".pdi") || content.includes(".pdx") || content.includes(".prc") || content.includes(".sql") || content.includes(".rec") || content.includes(".rel") || content.includes(".rin") || content.includes(".sdb") || content.includes(".sdf") || content.includes(".sqlite") || content.includes(".udl") || content.includes(".wadata") || content.includes(".waindx") || content.includes(".wamodel") || content.includes(".wajournal") || content.includes(".wdb") || content.includes(".wmdb")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Database";
		}
		else if (content.includes(".brd") || content.includes(".bsdl") || content.includes(".cdl") || content.includes(".cpf") || content.includes(".def") || content.includes(".dspf") || content.includes(".edif") || content.includes(".fsdb") || content.includes(".gdsii") || content.includes(".hex") || content.includes(".lef") || content.includes(".lib") || content.includes(".ms12") || content.includes(".oasis") || content.includes(".openaccess") || content.includes(".sdc") || content.includes(".sdf") || content.includes(".spef") || content.includes(".spi") || content.includes(".cir") || content.includes(".srec") || content.includes(".s19") || content.includes(".stil") || content.includes(".sv") || content.includes(".s*p") || content.includes(".upf") || content.includes(".v") || content.includes(".vcd") || content.includes(".vhd") || content.includes(".vhdl") || content.includes(".wgl")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Electronic Design Automation (EDA)";
		}
		else if (content.includes(".3dxml") || content.includes(".3mf") || content.includes(".acp") || content.includes(".amf") || content.includes(".aec") || content.includes(".ar") || content.includes(".art") || content.includes(".asc") || content.includes(".asm") || content.includes(".bin") || content.includes(".bim") || content.includes(".brep") || content.includes(".ccc") || content.includes(".ccm") || content.includes(".ccs") || content.includes(".cad") || content.includes(".catdrawing") || content.includes(".catpart") || content.includes(".catproduct") || content.includes(".catprocess") || content.includes(".cgr") || content.includes(".ckd") || content.includes(".ckt") || content.includes(".co") || content.includes(".drw") || content.includes(".dft") || content.includes(".dgn") || content.includes(".dgk") || content.includes(".dmt") || content.includes(".dxf") || content.includes(".dwb") || content.includes(".dwf") || content.includes(".dwg") || content.includes(".easm") || content.includes(".edrw") || content.includes(".emb") || content.includes(".eprt") || content.includes(".escpcb") || content.includes(".escsch") || content.includes(".esw") || content.includes(".excellon") || content.includes(".exp") || content.includes(".f3d") || content.includes(".fm") || content.includes(".fmz") || content.includes(".g") || content.includes(".gbr") || content.includes(".glm") || content.includes(".grb") || content.includes(".gtc") || content.includes(".iam") || content.includes(".icd") || content.includes(".idw") || content.includes(".ifc") || content.includes(".iges") || content.includes(".isf") || content.includes(".ipn") || content.includes(".ipt") || content.includes(".jt") || content.includes(".mcd") || content.includes(".model") || content.includes(".ocd") || content.includes(".par") || content.includes(".pipe") || content.includes(".pln") || content.includes(".prt") || content.includes(".psm") || content.includes(".psmodel") || content.includes(".pwi") || content.includes(".pyt") || content.includes(".skp") || content.includes(".rlf") || content.includes(".rvm") || content.includes(".rvt") || content.includes(".rfa") || content.includes(".s12") || content.includes(".scad") || content.includes(".scdoc") || content.includes(".sldasm") || content.includes(".slddrw") || content.includes(".sldprt") || content.includes(".dotxsi") || content.includes(".step") || content.includes(".stl") || content.includes(".tct") || content.includes(".tcw") || content.includes(".unv") || content.includes(".vc6") || content.includes(".vlm") || content.includes(".vs") || content.includes(".wrl") || content.includes(".x_b") || content.includes(".x_t") || content.includes(".xe")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Computer-aided Design (CAD)";
		}
		else if (content.includes(".iso") || content.includes(".nrg") || content.includes(".img") || content.includes(".adf") || content.includes(".adz") || content.includes(".dms") || content.includes(".dsk") || content.includes(".d64") || content.includes(".sdi") || content.includes(".mds") || content.includes(".mdx") || content.includes(".dmg") || content.includes(".cdi") || content.includes(".cue") || content.includes(".cif") || content.includes(".c2d") || content.includes(".daa") || content.includes(".b6t")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Physical-recordable-media Archive";
		}
		else if (content.includes(".oeb") || content.includes(".oebps") || content.includes(".opc") || content.includes(".paq")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Document-packaging-and-distribution Archive";
		}
		else if (content.includes(".apk") || content.includes(".deb") || content.includes(".pkg") || content.includes(".rpm") || content.includes(".msi") || content.includes(".jar") || content.includes(".war") || content.includes(".java") || content.includes(".rar") || content.includes(".ear")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Software-packaging-and-distribution Archive";
		}
		else if (content.includes(".7z") || content.includes(".ace") || content.includes(".arc") || content.includes(".arj") || content.includes(".b1") || content.includes(".cabinet") || content.includes(".cfs") || content.includes(".cpt") || content.includes(".dgca") || content.includes("..dmg") || content.includes("..egg") || content.includes(".kgb") || content.includes(".lha") || content.includes(".lzx") || content.includes(".mpq") || content.includes(".pea") || content.includes(".rar") || content.includes(".rzip") || content.includes(".sit") || content.includes(".sqx") || content.includes(".uda") || content.includes(".xar") || content.includes(".zoo") || content.includes(".zip") || content.includes(".zpaq")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Archiving-and-compression Archive";
		}
		else if (content.includes(".bzip2") || content.includes(".gzip") || content.includes(".lzip") || content.includes(".lzma") || content.includes(".lzop") || content.includes(".xz") || content.includes(".sq") || content.includes(".compress")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Compression-only Archive";
		}
		else if (content.includes(".ar") || content.includes(".cpio") || content.includes(".shar") || content.includes(".tar") || content.includes(".lbr") || content.includes(".bagit") || content.includes(".wad")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Archiving-only Archive";
		}
		else if (content.includes(".ani") || content.includes(".anim") || content.includes(".apng") || content.includes(".art") || content.includes(".bmp") || content.includes(".bpg") || content.includes(".bsave") || content.includes(".cal") || content.includes(".cin") || content.includes(".cpc") || content.includes(".cpt") || content.includes(".dds") || content.includes(".dpx") || content.includes(".ecw") || content.includes(".exr") || content.includes(".fits") || content.includes(".flic") || content.includes(".flif") || content.includes(".fpx") || content.includes(".gif") || content.includes(".hdri") || content.includes(".hevc") || content.includes(".icer") || content.includes(".icns") || content.includes(".ico") || content.includes(".cur") || content.includes(".ics") || content.includes(".ilbm") || content.includes(".jbig") || content.includes(".jbig2") || content.includes(".jng") || content.includes(".jpeg") || content.includes(".jpeg") || content.includes(".2000") || content.includes(".jpeg-ls") || content.includes(".jpeg") || content.includes(".xr") || content.includes(".kra") || content.includes(".mng") || content.includes(".miff") || content.includes(".nrrd") || content.includes(".ora") || content.includes(".pam") || content.includes(".pbm") || content.includes(".pgm") || content.includes(".ppm") || content.includes(".pnm") || content.includes(".pcx") || content.includes(".pgf") || content.includes(".pictor") || content.includes(".png") || content.includes(".psd") || content.includes(".psb") || content.includes(".psp") || content.includes(".qtvr") || content.includes(".ras") || content.includes(".rbe") || content.includes(".jpeg-hdr") || content.includes(".logluv") || content.includes(".tiff") || content.includes(".sgi") || content.includes(".tga") || content.includes(".tiff") || content.includes(".tiff") || content.includes(".tiff") || content.includes(".ufo") || content.includes(".ufp") || content.includes(".wbmp") || content.includes(".webp") || content.includes(".xbm") || content.includes(".xcf") || content.includes(".xpm") || content.includes(".xwd") || content.includes(".ciff") || content.includes(".dng") || content.includes(".ai") || content.includes(".cdr") || content.includes(".cgm") || content.includes(".dxf") || content.includes(".eva") || content.includes(".emf") || content.includes(".gerber") || content.includes(".hvif") || content.includes(".iges") || content.includes(".pgml") || content.includes(".svg") || content.includes(".vml") || content.includes(".wmf") || content.includes(".xar") || content.includes(".cdf") || content.includes(".djvu") || content.includes(".eps") || content.includes(".pdf") || content.includes(".pict") || content.includes(".ps") || content.includes(".swf") || content.includes(".xaml") || content.includes(".exif") || content.includes(".xmp")) {
			downloadType.classList.remove("hidden");
			downloadTypeVar.textContent = "Graphics";
		}
		else {
		downloadType.classList.add("hidden");
		}
	}
});
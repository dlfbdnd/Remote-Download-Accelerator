var button = document.querySelector("#startButton")
var pleaseWait = document.querySelector("#pleaseWait");
var isThere = false;

button.addEventListener("click", function(){
	setInterval(function(){
		if (isThere){
			pleaseWait.classList.remove("hidden");
			isThere = false;
		}
		else {
			pleaseWait.classList.add("hidden");
			isThere = true;
		}
	}, 1100);
});
document.querySelector("#IconR0").style.opacity = "1";

setTimeout(function() {
  document.querySelector("#IconR1").style.opacity = "1";
}, 300);

setTimeout(function() {
  document.querySelector("#IconR2").style.opacity = "1";
}, 600);

setTimeout(function() {
  document.querySelector("#Icon0").style.opacity = "1";
}, 900);

setTimeout(function() {
  document.querySelector("#Icon1").style.opacity = "1";
}, 1200);
document.querySelector("#IconR0").addEventListener("click", function() {
	location.href = "https://en.wikipedia.org/wiki/Hypertext_Transfer_Protocol";
});

document.querySelector("#IconR1").addEventListener("click", function() {
	location.href = "https://en.wikipedia.org/wiki/HTTPS";
});

document.querySelector("#IconR2").addEventListener("click", function() {
	location.href = "https://en.wikipedia.org/wiki/File_Transfer_Protocol";
});

document.querySelector("#Icon0").addEventListener("click", function() {
	location.href = "https://www.youtube.com/";
});

document.querySelector("#Icon1").addEventListener("click", function() {
	location.href = "http://www.xiami.com/";
});

// document.querySelector("#Icon1").addEventListener("click", function() {
// 	location.href = "";
// });


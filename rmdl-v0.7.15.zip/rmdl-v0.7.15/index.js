var app = require("express")();
const cp = require('child_process');
const humanReadable = require('pretty-bytes');
var bodyParser = require("body-parser");
var express = require('express'), app = express();
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
	


String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};
String.prototype.appropriateLength = function(len) { // somelongstr -> 3 -> som...
	if (this.length == 0) return "";
	if (this.length <= len) return this;
	return this.substring(0, len+1) + "...";
}
Number.prototype.padFormat = function(nDigit) { // a = 7; a.padFormat(3) == "007"; b = 2018; b.padFormat(2) == "18";
	var str = this.toString();
	if (isNaN(parseFloat(nDigit)) && isFinite(nDigit)) return str; // if nDigit is not a Number
	while (str.length > nDigit) {
		str = str.substring(1);
	}
	while (str.length < nDigit) {
		str = 0 + str;
	}
	return str;
};



// Main Page
app.get("/", function (req, res) {
    res.render("index.ejs");
});

app.get("/youtube", function (req, res) {
	res.render("comingSoon.ejs");
});

app.get("/twitter", function (req, res) {
	res.render("comingSoon.ejs");
});

app.get("/about", function (req, res) {
	res.render("comingSoon.ejs");
});

app.post("/download", function (req, res) {
	var addr = req.body.addr;
	var customFileName = req.body.customFileName;
	if (addr == "" || !addr.includes("://")) {
		res.render("addrErr.ejs");
		return -1;
	}
	var date = new Date();
	var timeID = date.getFullYear().padFormat(2) + date.getMonth().padFormat(2) + date.getDate().padFormat(2) + date.getHours().padFormat(2) + date.getMinutes().padFormat(2) + date.getSeconds().padFormat(2) + date.getMilliseconds().padFormat(3);
	if (customFileName == "") { // Two different wget(s) for different file name situations
		cp.execSync('mkdir ./dl/' + timeID);
		var wget = cp.exec('wget --limit-rate=100m --trust-server-names -P ./dl/' + timeID + '/ \"' + addr + '\"', {maxBuffer: 200*1024*1024}, (error, stdout, stderr) => { // maxBuffer by default is 200*1024, but increased due to wget's massive outputs. If not download WILL stop before finishing.
		  if (error) { // The following lines within "=>{}" are for DEBUG purposes
		    console.error(`exec error: ${error}`);
		    return;
		  }
		  // console.log(`stdout: ${stdout}`);
		  // console.log(`stderr: ${stderr}`);
		});
		var pid = wget.pid;
	} else {
		cp.execSync('mkdir ./dl/' + timeID);
		var wget = cp.exec('wget --limit-rate=100m --trust-server-names -O ./dl/' + timeID + '/' + customFileName + ' \"' + addr + '\"', {maxBuffer: 200*1024*1024}, (error, stdout, stderr) => { // maxBuffer by default is 200*1024, but increased due to wget's massive outputs. If not download WILL stop before finishing.
		  if (error) { // The following lines within "=>{}" are for DEBUG purposes
		    console.error(`exec error: ${error}`);
		    return;
		  }
		  // console.log(`stdout: ${stdout}`);
		  // console.log(`stderr: ${stderr}`);
		});
		var pid = wget.pid;
	}
	res.render("downloading.ejs", {
		addr: addr,
		shortAddr: addr.appropriateLength(75),
		shortFilename: customFileName.appropriateLength(69),
		ID: timeID.toString(), // Alternative name to reduce risk of attack
		pp: pid // Alternative name to reduce risk of attack
	});
});

app.post("/killProcess", function (req, res) { // Kill the process by pid provided by client
	var timeID = req.body.ID;
	cp.exec('rm -r ./dl/' + timeID + '*');
	var pid = req.body.pp;
	var checkIfPidExists = cp.execSync('if ps -p ' + pid + ' > /dev/null; then echo "exists"; fi').toString().trim(); // execSync returns buffer
	if (checkIfPidExists == "exists") cp.execSync('kill ' + pid); // kill only if it exists
});

app.post("/getShortFilename", function (req, res) { // Get the file name on disk and truncate it using appropriateLength() method (see above)
	var timeID = req.body.ID;
	var fileName = cp.execSync('ls \"./dl/' + timeID + '/\"').toString().trim(); // execSync returns buffer
	res.send(fileName.appropriateLength(69).trim().split('?')[0]);
});

app.post("/storeFileSize", function (req, res) { // Store the file size on disk by reading the http header of the online file
	var addr = req.body.addr;
	var timeID = req.body.ID;
	var cmd = ('curl -sIL \"' + addr + '\" | grep ength: | cut -d\" \" -f 2 > ./dl/' + timeID + '.txt'); // grep "ength:" because some server provides "Content-Length:" but others provides "content-length". -s silent output, -I request header, -L follow all redirects
	cp.exec(cmd);
});

app.post("/getFileSize", function (req, res) { // Get the total file size that was previously store on disk
	var timeID = req.body.ID;
	var isHumanReadable = req.body.forHuman;
	if ((cp.execSync('[ -f ./dl/' + timeID + '.txt ] && echo "exists" || echo ""').toString().trim()) == "") { // if filesize doesn't exist
		res.send("Unknown");
		return;
	}
	var filesize = cp.execSync('cat ./dl/' + timeID + '.txt').toString().trim();
	if (isHumanReadable) {
		filesize = (filesize != "")? humanReadable(Number(filesize)).toString().toUpperCase() : ""; // if filesize exists, turn e.g. 395123 to "395 KB"
	}
	(filesize == "")? filesize = "Unknown" : (filesize.substring(filesize.length-2) == " B" || filesize.substring(filesize.length-2) == "KB" || (filesize.substring(filesize.length-2) == "MB" && filesize.charAt(1) == '.'))? filesize = "≥ " + filesize : filesize = filesize; // if filesize does not exist return "Unknown", else if file size is smaller than 10 MB make it look like an approximation
	res.send(filesize);
});

app.post("/storeCurrentSize", function (req, res) { // Constantly storing the current file size
	var timeID = req.body.ID;
	var frequency = req.body.mc * 1000; // mc is the interval in second between each interval loop
	var cmd = ('du -s -B1 ./dl/' + timeID + '/* | sort -rn | awk \'NR==1{print $1}\' > ./dl/' + timeID + '.current.txt'); // summarize size of items in cwd in Bytes(-B1) -> sort from large to small in bits -> print the first size (largest) -> store it in file
	var fileExists = 0;
	var IntervalLoop = setInterval(function() {
		cp.exec(cmd);
		if ( (cp.execSync('[ -f ./dl/' + timeID + '.current.txt ] && echo "exists" || echo ""').toString().trim()) == "exists" && (cp.execSync('[ -f ./dl/' + timeID + '.txt ] && echo "exists" || echo ""').toString().trim()) == "exists") { // if the files containing the size exist (the files containing the size get deleted when user clicks the CANCEL button (POST /killProcess), the next if statement will go wrong if files to be read does not exist)
			fileExists++;
			if (Number(cp.execSync('cat ./dl/' + timeID + '.txt').toString().trim()) - Number(cp.execSync('cat ./dl/' + timeID + '.current.txt').toString().trim()) <= 0) { // if the remaining file size is <= 0 (i.e. download is done)
				clearInterval(IntervalLoop); // Basically, this runs when download is finished
			}
		} else { // if files containing size info do not exists
			if (fileExists > 0) { // But they had existed before
				clearInterval(IntervalLoop); // Basically, this runs when user clicks cancel
			}
		}
	}, frequency);
});

app.post("/getCurrentSize", function (req, res) { // Get the size of the current file by reading a .current.txt file that was previously generated (or updated) previously
	var timeID = req.body.ID;
	var isHumanReadable = req.body.forHuman;
	if ((cp.execSync('[ -f ./dl/' + timeID + '.txt ] && echo "exists" || echo ""').toString().trim()) == "") { // if filesize doesn't exist
		res.send("------");
		return;
	}
	var filesize = cp.execSync('cat ./dl/' + timeID + '.current.txt').toString().trim();
	if (isHumanReadable) {
		filesize = (filesize != "")? humanReadable(Number(filesize)).toString().toUpperCase() : ""; // if filesize exists, turn e.g. 395123 to "395 KB"
	}
	(filesize == "")? filesize = "------" : filesize = filesize;
	var filesizeTotal = Number(cp.execSync('cat ./dl/' + timeID + '.txt').toString().trim()) - Number(cp.execSync('cat ./dl/' + timeID + '.current.txt').toString().trim()); // If remaining size is smaller than 0 (i.e. download finished)
	if (filesizeTotal <= 0) {
		filesize = "✅"; // Will display this when download is finished
	}
	res.send(filesize);
});

app.post("/getRemainingSize", function (req, res) { // Get the remaining size of the file by substracting the values in two files which are previously generated (or updated) previously
	var timeID = req.body.ID;
	var isHumanReadable = req.body.forHuman;
	var isZeroOrSmaller = false;
	if ((cp.execSync('[ -f ./dl/' + timeID + '.txt ] && echo "exists" || echo ""').toString().trim()) == "") { // if filesize doesn't exist
		res.send("------");
		return;
	}
	var filesize = Number(cp.execSync('cat ./dl/' + timeID + '.txt').toString().trim()) - Number(cp.execSync('cat ./dl/' + timeID + '.current.txt').toString().trim());
	if (filesize <= 0) {
		isZeroOrSmaller = true;
	}
	if (isHumanReadable) {
		filesize = (filesize != "")? humanReadable(Number(filesize)).toString().toUpperCase() : ""; // if filesize exists, turn e.g. 395123 to "395 KB"
	}
	if (isZeroOrSmaller) {
		filesize = "0 B";
	}
	res.send(filesize);
});

app.post("/getPercentage", function (req, res) { // Get the percentage of the download progress by substracting the values that are stored in each of the two files which are generated (or updated) prevsiouly
	var timeID = req.body.ID;
	var currentSize = parseFloat(cp.execSync('cat ./dl/' + timeID + '.current.txt').toString().trim()); // parseFloat(), parseInt(), Number() all convert to numbers
	var totalSize =  parseFloat(cp.execSync('cat ./dl/' + timeID + '.txt').toString().trim()); // parseFloat(), parseInt(), Number() all convert to numbers
	var percentage = ((currentSize / totalSize)*100).toFixed(1).toString(); // toFixed(keepNDigitsAfterDecimal)
	(percentage > 100)? percentage = "100" : percentage = percentage.toString();
	(percentage == "NaN")? percentage = "--.-" : percentage = percentage.toString();
	res.send(percentage);
});

app.get("/getFile", function (req, res) { // BUG: Requires attack proof
	var timeID = req.query.ID; // req.params and req.query are both applicable, but different in usage
	if ((cp.execSync('[ -d ./dl/' + timeID + '/ ] && echo "exists" || echo ""').toString().trim()) == "") { // if timeID does not match any of the directories (i.e. directory timeID does not exist)
		res.render("addrErr.ejs");
		return;
	}
	var pid = req.query.pp;
	var filename = cp.execSync('ls \"./dl/' + timeID + '/\"').toString().trim();
	if ((cp.execSync('[ -f ./dl/' + timeID + '/\"' + filename + '\" ] && echo "exists" || echo ""').toString().trim()) == "") { // if requested target file doesn't exist
		res.render("addrErr.ejs");
		return;
	}
	var IntervalLoop =  setInterval(function() { // Wait until pid.wget has exited THEN send the file
		if (cp.execSync('if ps -p ' + pid + ' > /dev/null; then echo "exists"; fi').toString().trim() == "") {
			res.sendFile(__dirname + '/dl/' + timeID + '/' + filename); // __dirname is the pwd
			clearInterval(IntervalLoop);
		}
	}, 200);
});

app.get("/reset", function (req, res) { // Admin option, used to kill all the download tasks (may break some front-ends) and clean up the cached files in ./dl/ folder
	cp.exec('killall wget');
	cp.exec('rm -r ./dl/*');
	res.render("index.ejs");
});

app.get("*", function (req, res) {
    res.render("addrErr.ejs");
});

app.listen(80);